(() => {
  'use strict';

  const PUZZLES = [
    { id: 'hero', title: 'Lightning Hero', category: 'Heroes', collection: 'originals' },
    { id: 'monster', title: 'Monster Attack', category: 'Monsters', collection: 'originals' },
    { id: 'rocket', title: 'Space Rocket', category: 'Space', collection: 'originals' },
    { id: 'tiger', title: 'Jungle Tiger', category: 'Jungle', collection: 'originals' },
    { id: 'pirate', title: 'Pirate Island', category: 'Pirates', collection: 'originals' },
    { id: 'robot', title: 'Retro Robot', category: 'Robots', collection: 'originals' },
    { id: 'pharaoh', title: 'Golden Pharaoh', category: 'Egypt', collection: 'originals' },
    { id: 'trex', title: 'T-Rex Volcano', category: 'Dinosaurs', collection: 'originals' },
    { id: 'neon', title: 'Neon Racer', category: 'Neon City', collection: 'originals' },
    { id: 'submarine', title: 'Deep Sea Ruins', category: 'Ocean', collection: 'originals' },
    { id: 'dragon', title: 'Dragon Castle', category: 'Fantasy', collection: 'originals' },
    { id: 'astronaut', title: 'Alien Explorer', category: 'Space', collection: 'originals' },
    { id: 'polar', title: 'Polar Expedition', category: 'Arctic', collection: 'originals' },

    { id: 'japan-01', title: 'Red Samurai', category: 'Samurai & Japan', collection: 'japan' },
    { id: 'japan-02', title: 'Moon Ninja', category: 'Samurai & Japan', collection: 'japan' },
    { id: 'japan-03', title: 'Sunset Castle', category: 'Samurai & Japan', collection: 'japan' },
    { id: 'japan-04', title: 'Kitsune Shrine', category: 'Samurai & Japan', collection: 'japan' },
    { id: 'japan-05', title: 'Oni Moon', category: 'Samurai & Japan', collection: 'japan' },
    { id: 'japan-06', title: 'Sakura Samurai', category: 'Samurai & Japan', collection: 'japan' },
    { id: 'japan-07', title: 'Koi Pond', category: 'Samurai & Japan', collection: 'japan' },
    { id: 'japan-08', title: 'Torii & Fuji', category: 'Samurai & Japan', collection: 'japan' },
    { id: 'japan-09', title: 'Dragon Pagoda', category: 'Samurai & Japan', collection: 'japan' },
    { id: 'japan-10', title: 'Lantern Temple', category: 'Samurai & Japan', collection: 'japan' },

    { id: 'fantasy-01', title: 'Wizard Bridge', category: 'Epic Fantasy', collection: 'fantasy' },
    { id: 'fantasy-02', title: 'Golden Ring', category: 'Epic Fantasy', collection: 'fantasy' },
    { id: 'fantasy-03', title: 'Elven City', category: 'Epic Fantasy', collection: 'fantasy' },
    { id: 'fantasy-04', title: 'Dwarf Forge', category: 'Epic Fantasy', collection: 'fantasy' },
    { id: 'fantasy-05', title: 'Hillside Home', category: 'Epic Fantasy', collection: 'fantasy' },
    { id: 'fantasy-06', title: 'Forest Guardian', category: 'Epic Fantasy', collection: 'fantasy' },
    { id: 'fantasy-07', title: 'Dark Fortress', category: 'Epic Fantasy', collection: 'fantasy' },
    { id: 'fantasy-08', title: 'Eagle Rider', category: 'Epic Fantasy', collection: 'fantasy' },
    { id: 'fantasy-09', title: 'Green Ranger', category: 'Epic Fantasy', collection: 'fantasy' },
    { id: 'fantasy-10', title: 'Mountain Fellowship', category: 'Epic Fantasy', collection: 'fantasy' },

    { id: 'horror-01', title: 'Haunted Scarecrow', category: 'Retro Horror', collection: 'horror' },
    { id: 'horror-02', title: 'Carnival Clown', category: 'Retro Horror', collection: 'horror' },
    { id: 'horror-03', title: 'Under the Bed', category: 'Retro Horror', collection: 'horror' },
    { id: 'horror-04', title: 'Ghost Train', category: 'Retro Horror', collection: 'horror' },
    { id: 'horror-05', title: 'Swamp Creature', category: 'Retro Horror', collection: 'horror' },
    { id: 'horror-06', title: 'Cursed Dummy', category: 'Retro Horror', collection: 'horror' },
    { id: 'horror-07', title: 'Pumpkin Nightmare', category: 'Retro Horror', collection: 'horror' },
    { id: 'horror-08', title: 'Museum Mummy', category: 'Retro Horror', collection: 'horror' },
    { id: 'horror-09', title: 'Ghost Pirate', category: 'Retro Horror', collection: 'horror' },
    { id: 'horror-10', title: 'Monster Greenhouse', category: 'Retro Horror', collection: 'horror' },
  ];

  const COLLECTIONS = [
    { id: 'all', label: 'ALL', count: PUZZLES.length },
    { id: 'originals', label: 'ORIGINALS', count: 13 },
    { id: 'japan', label: 'SAMURAI & JAPAN', count: 10 },
    { id: 'fantasy', label: 'EPIC FANTASY', count: 10 },
    { id: 'horror', label: 'RETRO HORROR', count: 10 },
  ];

  const app = document.getElementById('app');
  const recordsKey = 'slide-tales-records-v1';
  const prefsKey = 'slide-tales-prefs-v1';

  function puzzleSrc(id) { return './assets/puzzles/' + id + '.webp'; }
  function thumbSrc(id) { return './assets/thumbs/' + id + '.webp'; }

  function loadJson(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (_) {
      return fallback;
    }
  }

  const savedPrefs = loadJson(prefsKey, {});
  const state = {
    screen: 'home',
    size: savedPrefs.size === 3 ? 3 : 4,
    filter: savedPrefs.filter || 'originals',
    current: PUZZLES[0],
    board: [],
    initial: [],
    moves: 0,
    seconds: 0,
    running: false,
    paused: false,
    hint: false,
    guide: false,
    won: false,
    records: loadJson(recordsKey, {}),
  };

  function savePrefs() {
    localStorage.setItem(prefsKey, JSON.stringify({ size: state.size, filter: state.filter }));
  }

  function solvedBoard(size) {
    return Array.from({ length: size * size }, (_, i) => i === size * size - 1 ? 0 : i + 1);
  }

  function isSolved(board, size) {
    const solved = solvedBoard(size);
    return board.every((value, index) => value === solved[index]);
  }

  function neighbors(index, size) {
    const row = Math.floor(index / size);
    const col = index % size;
    const result = [];
    if (row > 0) result.push(index - size);
    if (row < size - 1) result.push(index + size);
    if (col > 0) result.push(index - 1);
    if (col < size - 1) result.push(index + 1);
    return result;
  }

  function shuffledBoard(size) {
    const board = solvedBoard(size);
    let blank = board.length - 1;
    let previous = -1;
    const steps = size === 3 ? 100 : 240;
    for (let step = 0; step < steps; step += 1) {
      let options = neighbors(blank, size).filter(value => value !== previous);
      if (!options.length) options = neighbors(blank, size);
      const next = options[Math.floor(Math.random() * options.length)];
      board[blank] = board[next];
      board[next] = 0;
      previous = blank;
      blank = next;
    }
    if (isSolved(board, size)) {
      const next = neighbors(blank, size)[0];
      board[blank] = board[next];
      board[next] = 0;
    }
    return board;
  }

  function recordKey(id, size) { return id + '-' + size + 'x' + size; }
  function resultStars(size, moves) {
    if (size === 3) return moves <= 35 ? 3 : moves <= 55 ? 2 : 1;
    return moves <= 80 ? 3 : moves <= 130 ? 2 : 1;
  }

  function totalStars() {
    return Object.values(state.records).reduce((sum, record) => sum + Number(record.stars || 0), 0);
  }

  function saveRecord() {
    const key = recordKey(state.current.id, state.size);
    const stars = resultStars(state.size, state.moves);
    const previous = state.records[key];
    const better = !previous || stars > previous.stars ||
      (stars === previous.stars && state.moves < previous.moves) ||
      (stars === previous.stars && state.moves === previous.moves && state.seconds < previous.seconds);
    if (better) {
      state.records[key] = { moves: state.moves, seconds: state.seconds, stars };
      localStorage.setItem(recordsKey, JSON.stringify(state.records));
    }
  }

  function formatTime(value) {
    const mins = String(Math.floor(value / 60)).padStart(2, '0');
    const secs = String(value % 60).padStart(2, '0');
    return mins + ':' + secs;
  }

  function haptic(ms = 8) {
    try {
      if (window.Android && typeof window.Android.vibrate === 'function') window.Android.vibrate(ms);
      else if (navigator.vibrate) navigator.vibrate(ms);
    } catch (_) {}
  }

  function starMarkup(stars) {
    return [1,2,3].map(i => '<span class="' + (stars >= i ? 'earned' : '') + '">★</span>').join('');
  }

  function shell(content) {
    return '<div class="shell">' + header() + content + '</div>';
  }

  function header() {
    return '<header class="topbar">' +
      '<button class="icon-btn" data-action="settings" aria-label="How to play">?</button>' +
      '<div class="logo"><span class="slide">SLIDE</span><span class="tales">TALES</span></div>' +
      '<div class="star-badge" aria-label="Total stars">★ ' + totalStars() + '</div>' +
    '</header>';
  }

  function levelSelector() {
    return '<div class="level-selector">' +
      '<button class="level-button easy ' + (state.size === 3 ? 'active' : '') + '" data-action="size" data-size="3"><strong>3 x 3</strong><span>EASY</span><small>8 tiles</small></button>' +
      '<button class="level-button ' + (state.size === 4 ? 'active' : '') + '" data-action="size" data-size="4"><strong>4 x 4</strong><span>CLASSIC</span><small>15 tiles</small></button>' +
    '</div>';
  }

  function previewGrid() {
    return '<div class="preview-grid" style="--n:' + state.size + '">' +
      Array.from({ length: state.size * state.size }, () => '<i></i>').join('') + '</div>';
  }

  function renderHome() {
    const featured = PUZZLES[Math.floor(Date.now() / 86400000) % PUZZLES.length];
    return shell('<section class="screen">' +
      '<p class="hero-copy">SMALL PUZZLES<br>BIG COMIC ADVENTURES!</p>' +
      '<p class="section-kicker">CHOOSE LEVEL</p>' + levelSelector() +
      '<div class="preview"><img src="' + puzzleSrc(featured.id) + '" alt="' + featured.title + '">' + previewGrid() + '<span class="preview-chip">' + state.size + ' x ' + state.size + '</span></div>' +
      '<button class="action red play" data-action="play" data-id="' + featured.id + '">▶ PLAY DAILY PICK</button>' +
      '<div class="home-actions">' +
        '<button class="action blue" data-action="collection">▦<span>COLLECTIONS</span></button>' +
        '<button class="action green" data-action="daily">★<span>DAILY PUZZLE</span></button>' +
      '</div>' +
      '<div class="home-secondary">' +
        '<button class="action salmon" data-action="help">? HOW TO SOLVE 4x4</button>' +
        '<button class="action black" data-action="settings">⚙ HOW TO PLAY</button>' +
      '</div>' +
    '</section>');
  }

  function collectionProgress(collectionId) {
    const list = collectionId === 'all' ? PUZZLES : PUZZLES.filter(p => p.collection === collectionId);
    const solved = list.filter(p => Boolean(state.records[recordKey(p.id, state.size)])).length;
    return solved + ' / ' + list.length + ' solved';
  }

  function renderCollection() {
    const list = state.filter === 'all' ? PUZZLES : PUZZLES.filter(p => p.collection === state.filter);
    const tabs = COLLECTIONS.map(c => '<button class="collection-tab ' + (state.filter === c.id ? 'active' : '') + '" data-action="filter" data-filter="' + c.id + '"><strong>' + c.label + '</strong><small>' + c.count + ' puzzles</small></button>').join('');
    const cards = list.map(p => {
      const record = state.records[recordKey(p.id, state.size)];
      const collectionLabel = COLLECTIONS.find(c => c.id === p.collection)?.label || p.category;
      return '<button class="card" data-action="play" data-id="' + p.id + '">' +
        '<div class="card-art"><img loading="lazy" decoding="async" src="' + thumbSrc(p.id) + '" alt="' + p.title + '"><span class="card-chip">' + collectionLabel + '</span><span class="grid-chip">' + state.size + 'x' + state.size + '</span></div>' +
        '<strong>' + p.title + '</strong><span class="category">' + p.category + '</span>' +
        '<div class="card-footer"><div class="card-stars">' + starMarkup(record?.stars || 0) + '</div><small>' + (record ? record.moves + ' moves' : 'Not solved') + '</small></div>' +
      '</button>';
    }).join('');
    return shell('<section class="screen">' +
      '<div class="title-row"><button class="back" data-action="home">←</button><div><h1>COLLECTIONS</h1><p>43 offline puzzles. Pick a theme and play instantly.</p></div></div>' +
      levelSelector() + '<div class="collection-tabs">' + tabs + '</div>' +
      '<div class="collection-summary"><b>' + state.size + ' x ' + state.size + '</b><span>' + collectionProgress(state.filter) + '</span></div>' +
      '<div class="cards">' + cards + '</div>' +
      '<nav class="bottom-nav"><button data-action="home">⌂ HOME</button><button class="active" data-action="collection">▦ COLLECTIONS</button></nav>' +
    '</section>');
  }

  function tileMarkup(value, index) {
    if (value === 0) return '<div class="tile empty" aria-label="Empty space"></div>';
    const original = value - 1;
    const row = Math.floor(original / state.size);
    const col = original % state.size;
    const denom = Math.max(1, state.size - 1);
    const x = (col * 100) / denom;
    const y = (row * 100) / denom;
    const correct = value === index + 1;
    return '<button class="tile ' + (correct ? 'correct' : '') + '" data-action="tile" data-index="' + index + '" data-value="' + value + '" aria-label="Move tile ' + value + '" style="background-image:url(\'' + puzzleSrc(state.current.id) + '\');background-size:' + (state.size * 100) + '% ' + (state.size * 100) + '%;background-position:' + x + '% ' + y + '%"></button>';
  }

  function gameOverlay() {
    if (state.won) {
      const stars = resultStars(state.size, state.moves);
      return '<div class="overlay"><h2>PUZZLE COMPLETE!</h2><div class="win-stars">' + starMarkup(stars) + '</div><p>' + state.current.title + '<br>' + state.moves + ' moves · ' + formatTime(state.seconds) + '</p><div class="overlay-actions"><button class="action red" data-action="replay">PLAY AGAIN</button><button class="action blue" data-action="collection">COLLECTIONS</button></div></div>';
    }
    if (state.paused) {
      return '<div class="overlay"><h2>PAUSED</h2><p>Your puzzle stays exactly where you left it.</p><button class="action blue" data-action="resume">RESUME</button></div>';
    }
    if (state.hint) {
      return '<div class="overlay"><h2>HINT</h2><img src="' + puzzleSrc(state.current.id) + '" alt="Puzzle guide"><p>Memorize the big shapes and colors.</p></div>';
    }
    if (state.guide) {
      return '<div class="overlay"><h2>ORIGINAL IMAGE</h2><img src="' + puzzleSrc(state.current.id) + '" alt="Original puzzle"><p>The timer is paused while the guide is open.</p><button class="action blue" data-action="close-guide">BACK TO PUZZLE</button></div>';
    }
    return '';
  }

  function renderGame() {
    const record = state.records[recordKey(state.current.id, state.size)];
    return shell('<section class="screen game-screen">' +
      '<div class="game-head"><button class="back" data-action="collection">←</button><div class="mini"><b>' + state.moves + '</b><span>MOVES</span></div><div class="mini"><b id="time">' + formatTime(state.seconds) + '</b><span>TIME</span></div><button class="back" data-action="pause">Ⅱ</button></div>' +
      '<div class="now-playing"><strong>' + state.current.title + '</strong><span>' + state.current.category.toUpperCase() + ' · ' + state.size + 'x' + state.size + '</span></div>' +
      '<div class="board-frame"><div class="board" style="--n:' + state.size + '">' + state.board.map(tileMarkup).join('') + '</div>' + gameOverlay() + '</div>' +
      '<div class="controls"><button class="control blue" data-action="shuffle">↝<span>SHUFFLE</span></button><button class="control green" data-action="hint">✦<span>HINT</span></button><button class="control salmon" data-action="guide">◉<span>GUIDE</span></button><button class="control red" data-action="reset">↻<span>RESET</span></button></div>' +
      (state.size === 4 ? '<button class="game-help" data-action="help">? HOW TO SOLVE THE 4x4</button>' : '') +
      '<div class="progress"><span>★ ' + starMarkup(record?.stars || 0) + '</span><b>' + (record ? 'BEST ' + record.moves + ' MOVES · ' + formatTime(record.seconds) : 'SOLVE & COLLECT!') + '</b></div>' +
    '</section>');
  }

  function helpGrid(stage) {
    return '<div class="help-grid">' + Array.from({ length: 16 }, (_, i) => {
      const r = Math.floor(i / 4);
      const c = i % 4;
      const locked = stage === 1 ? r === 0 : stage === 2 ? r <= 1 : stage === 3 ? r <= 1 || c <= 1 : false;
      const pair = stage === 3 && r >= 2 && c <= 1;
      const final = stage === 4 && r >= 2 && c >= 2;
      const cls = final ? 'final' : pair ? 'pair' : locked ? 'locked' : '';
      return '<span class="' + cls + '">' + (i === 15 ? '□' : i + 1) + '</span>';
    }).join('') + '</div>';
  }

  function renderHelp() {
    return shell('<section class="screen">' +
      '<div class="title-row"><button class="back" data-action="back-from-help">←</button><div><h1>SOLVE 4x4</h1><p>Layer + Pairs technique, made visual.</p></div></div>' +
      '<div class="help-intro"><h2>Think in locked zones</h2><p>Solve a band, stop moving through it, and keep shrinking the active area. Use the blank space as the tool that rotates pieces into position.</p></div>' +
      '<article class="help-card"><div class="help-num">1</div><div><h3>Finish row 1</h3><p>Build 1, 2, then prepare 3 and 4 as a pair. Rotate the last local 2x2 so both land together.</p></div>' + helpGrid(1) + '</article>' +
      '<article class="help-card"><div class="help-num">2</div><div><h3>Finish row 2</h3><p>Repeat with 5 through 8. Once the first two rows are correct, never bring the blank back into them.</p></div>' + helpGrid(2) + '</article>' +
      '<article class="help-card"><div class="help-num">3</div><div><h3>Build vertical pairs</h3><p>In the bottom half, pair 9 with 13, then 10 with 14. Lock each vertical pair from left to right.</p></div>' + helpGrid(3) + '</article>' +
      '<article class="help-card"><div class="help-num">4</div><div><h3>Rotate the final 2x2</h3><p>Only 11, 12, 15 and the blank remain. Circle the blank around that 2x2 until the image closes.</p></div>' + helpGrid(4) + '</article>' +
      '<div class="help-note">Corner Pair Trick: do not force the final tile of a row by itself. Stage the final two pieces together, move the blank around them, then rotate both into place.</div>' +
      '<button class="action black" data-action="practice4">▶ PRACTICE 4x4</button>' +
    '</section>');
  }

  function render() {
    if (state.screen === 'home') app.innerHTML = renderHome();
    else if (state.screen === 'collection') app.innerHTML = renderCollection();
    else if (state.screen === 'game') app.innerHTML = renderGame();
    else app.innerHTML = renderHelp();
  }

  function startRound(puzzle, size = state.size) {
    const board = shuffledBoard(size);
    state.size = size;
    state.current = puzzle;
    state.board = board.slice();
    state.initial = board.slice();
    state.moves = 0;
    state.seconds = 0;
    state.running = false;
    state.paused = false;
    state.hint = false;
    state.guide = false;
    state.won = false;
    state.screen = 'game';
    savePrefs();
    preloadPuzzle(puzzle.id);
    render();
  }

  function resetRound() {
    state.board = state.initial.slice();
    state.moves = 0;
    state.seconds = 0;
    state.running = false;
    state.paused = false;
    state.hint = false;
    state.guide = false;
    state.won = false;
    render();
  }

  function preloadPuzzle(id) {
    const image = new Image();
    image.src = puzzleSrc(id);
  }

  function capturePositions() {
    const map = new Map();
    document.querySelectorAll('.tile[data-value]').forEach(el => {
      map.set(Number(el.dataset.value), el.getBoundingClientRect());
    });
    return map;
  }

  function animatePositions(before) {
    requestAnimationFrame(() => {
      document.querySelectorAll('.tile[data-value]').forEach(el => {
        const previous = before.get(Number(el.dataset.value));
        if (!previous) return;
        const current = el.getBoundingClientRect();
        const dx = previous.left - current.left;
        const dy = previous.top - current.top;
        if (Math.abs(dx) < 1 && Math.abs(dy) < 1) return;
        el.animate([
          { transform: 'translate(' + dx + 'px,' + dy + 'px) scale(.985)', filter: 'brightness(1.14)' },
          { transform: 'translate(0,0) scale(1)', filter: 'brightness(1)' }
        ], { duration: 165, easing: 'cubic-bezier(.22,.9,.32,1)' });
      });
    });
  }

  function invalidMove() {
    const board = document.querySelector('.board-frame');
    if (!board) return;
    board.classList.remove('invalid');
    void board.offsetWidth;
    board.classList.add('invalid');
    haptic(24);
  }

  function moveTile(index) {
    if (state.paused || state.hint || state.guide || state.won) return;
    const size = state.size;
    const blank = state.board.indexOf(0);
    const br = Math.floor(blank / size);
    const bc = blank % size;
    const tr = Math.floor(index / size);
    const tc = index % size;
    if (index === blank || (br !== tr && bc !== tc)) {
      invalidMove();
      return;
    }

    const before = capturePositions();
    const next = state.board.slice();
    let moved = 0;

    if (br === tr) {
      if (index < blank) {
        for (let p = blank; p > index; p -= 1) { next[p] = next[p - 1]; moved += 1; }
      } else {
        for (let p = blank; p < index; p += 1) { next[p] = next[p + 1]; moved += 1; }
      }
      next[index] = 0;
    } else {
      if (index < blank) {
        for (let p = blank; p > index; p -= size) { next[p] = next[p - size]; moved += 1; }
      } else {
        for (let p = blank; p < index; p += size) { next[p] = next[p + size]; moved += 1; }
      }
      next[index] = 0;
    }

    state.board = next;
    state.moves += moved;
    state.running = true;
    haptic(Math.min(20, 6 + moved * 3));

    if (isSolved(next, size)) {
      state.won = true;
      state.running = false;
      saveRecord();
      haptic(55);
    }

    render();
    animatePositions(before);
  }

  function showHint() {
    if (state.paused || state.guide || state.won) return;
    state.hint = true;
    render();
    setTimeout(() => {
      if (!state.hint) return;
      state.hint = false;
      render();
    }, 1500);
  }

  function showHowToPlay() {
    const message = 'Tap any tile in the same row or column as the empty space. Every tile between it and the gap slides together. Use HINT to peek at the image, GUIDE to study it, and RESET if you want the original shuffle again.';
    if (window.Android) {
      state.guide = false;
      const board = state.screen === 'game' ? document.querySelector('.board-frame') : null;
      if (board) {
        const modal = document.createElement('div');
        modal.className = 'overlay';
        modal.innerHTML = '<h2>HOW TO PLAY</h2><p>' + message + '</p><button class="action blue" data-action="dismiss-info">GOT IT</button>';
        board.appendChild(modal);
      } else alert(message);
    } else alert(message);
  }

  function handle(action, element) {
    if (action === 'home') {
      state.screen = 'home'; state.paused = false; state.hint = false; state.guide = false; render(); return;
    }
    if (action === 'collection') {
      state.screen = 'collection'; state.paused = false; state.hint = false; state.guide = false; render(); return;
    }
    if (action === 'size') {
      const size = Number(element.dataset.size);
      if (size === 3 || size === 4) { state.size = size; savePrefs(); render(); }
      return;
    }
    if (action === 'filter') {
      state.filter = element.dataset.filter || 'all'; savePrefs(); render(); return;
    }
    if (action === 'play') {
      const puzzle = PUZZLES.find(p => p.id === element.dataset.id) || PUZZLES[0]; startRound(puzzle); return;
    }
    if (action === 'daily') {
      startRound(PUZZLES[Math.floor(Date.now() / 86400000) % PUZZLES.length]); return;
    }
    if (action === 'tile') { moveTile(Number(element.dataset.index)); return; }
    if (action === 'shuffle') { startRound(state.current); return; }
    if (action === 'reset') { resetRound(); return; }
    if (action === 'replay') { startRound(state.current); return; }
    if (action === 'hint') { showHint(); return; }
    if (action === 'guide' && !state.paused && !state.won) { state.guide = true; state.running = false; render(); return; }
    if (action === 'close-guide') { state.guide = false; render(); return; }
    if (action === 'pause' && !state.won) { state.paused = true; state.running = false; render(); return; }
    if (action === 'resume') { state.paused = false; render(); return; }
    if (action === 'help') { state.screen = 'help'; state.running = false; render(); return; }
    if (action === 'back-from-help') { state.screen = 'home'; render(); return; }
    if (action === 'practice4') { startRound(state.current || PUZZLES[0], 4); return; }
    if (action === 'settings') { showHowToPlay(); return; }
    if (action === 'dismiss-info') { element.closest('.overlay')?.remove(); return; }
  }

  document.addEventListener('click', event => {
    const target = event.target.closest('[data-action]');
    if (target) handle(target.dataset.action, target);
  });

  document.addEventListener('keydown', event => {
    if (state.screen !== 'game') return;
    const key = event.key.toLowerCase();
    if (key === 'h') return showHint();
    if (key === 'g') { state.guide = !state.guide; state.running = false; return render(); }
    if (key === 'r') return resetRound();
    if (event.code === 'Space') { event.preventDefault(); state.paused = !state.paused; state.running = false; return render(); }
    if (state.paused || state.guide || state.hint || state.won) return;
    const size = state.size;
    const blank = state.board.indexOf(0);
    let moveIndex = -1;
    if ((event.key === 'ArrowLeft' || key === 'a') && blank % size > 0) moveIndex = blank - 1;
    if ((event.key === 'ArrowRight' || key === 'd') && blank % size < size - 1) moveIndex = blank + 1;
    if ((event.key === 'ArrowUp' || key === 'w') && blank >= size) moveIndex = blank - size;
    if ((event.key === 'ArrowDown' || key === 's') && blank < size * (size - 1)) moveIndex = blank + size;
    if (moveIndex >= 0) { event.preventDefault(); moveTile(moveIndex); }
  });

  setInterval(() => {
    if (!state.running || state.paused || state.won || state.guide || state.hint || state.screen !== 'game') return;
    state.seconds += 1;
    const time = document.getElementById('time');
    if (time) time.textContent = formatTime(state.seconds);
  }, 1000);

  document.addEventListener('visibilitychange', () => {
    if (document.hidden && state.screen === 'game' && !state.won) {
      state.paused = true;
      state.running = false;
      render();
    }
  });

  window.pauseForNative = () => {
    if (state.screen === 'game' && !state.won) {
      state.paused = true;
      state.running = false;
      render();
    }
  };

  window.handleAndroidBack = () => {
    if (state.screen === 'game') {
      if (state.guide || state.hint || state.paused) {
        state.guide = false; state.hint = false; state.paused = false; render(); return true;
      }
      state.screen = 'collection'; state.running = false; render(); return true;
    }
    if (state.screen === 'collection' || state.screen === 'help') {
      state.screen = 'home'; render(); return true;
    }
    return false;
  };

  preloadPuzzle(PUZZLES[0].id);
  render();
})();
