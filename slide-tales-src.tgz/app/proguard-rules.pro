-keepclassmembers class cl.slidetales.app.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
